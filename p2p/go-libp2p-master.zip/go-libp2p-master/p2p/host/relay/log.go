package relay

import (
	logging "github.com/ipfs/go-log"
)

var log = logging.Logger("autorelay")
