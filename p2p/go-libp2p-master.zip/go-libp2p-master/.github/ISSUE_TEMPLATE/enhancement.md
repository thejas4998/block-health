---
name: 'Enhancement'
about: 'Suggest an improvement to an existing go-libp2p feature.'
labels: enhancement
---

<!--
Note: If you'd like to suggest an idea related to libp2p but not specifically related to the go implementation, please file an issue at https://github.com/libp2p/libp2p instead. Even better, create a new topic on the forums (https://discuss.libp2p.io).

When requesting an _enhancement_, please be sure to include your motivation and try to be as specific as possible.
-->
